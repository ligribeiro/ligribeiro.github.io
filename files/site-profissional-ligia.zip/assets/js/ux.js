/* Botão "voltar ao topo": aparece após rolar, feedback de estado (Nielsen H1). */
(function(){
  var btn=document.querySelector('.to-top');
  if(!btn) return;
  window.addEventListener('scroll',function(){
    if(window.scrollY>600){btn.classList.add('show')}else{btn.classList.remove('show')}
  },{passive:true});
  btn.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})});
})();
