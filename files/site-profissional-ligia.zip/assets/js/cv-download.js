/* Seletor de download do CV: idioma (PT/EN) x versão (ATS/bonito). */
(function(){
  document.querySelectorAll('[data-cv-download]').forEach(function(btn){
    btn.addEventListener('click', function(e){
      e.preventDefault();
      var open = btn.parentNode.querySelector('.cv-pop');
      if(open){ open.remove(); btn.setAttribute('aria-expanded','false'); return; }
      var base = btn.getAttribute('href').replace(/assets\/cv\/.*$/, 'assets/cv/');
      var pop = document.createElement('div');
      pop.className='cv-pop'; pop.setAttribute('role','menu');
      pop.innerHTML =
        '<span class="cv-pop-lbl">para envio a pessoas</span>'+
        '<a role="menuitem" href="'+base+'Ligia_Ribeiro_CV_PT_bonito.pdf" download>Português — versão visual</a>'+
        '<a role="menuitem" href="'+base+'Ligia_Ribeiro_CV_EN_bonito.pdf" download>English — visual version</a>'+
        '<span class="cv-pop-lbl">para candidaturas online (ATS)</span>'+
        '<a role="menuitem" href="'+base+'Ligia_Ribeiro_CV_PT.pdf" download>Português — versão simples</a>'+
        '<a role="menuitem" href="'+base+'Ligia_Ribeiro_CV_EN.pdf" download>English — simple version</a>';
      btn.parentNode.style.position='relative';
      btn.parentNode.appendChild(pop);
      btn.setAttribute('aria-expanded','true');
      setTimeout(function(){
        document.addEventListener('click', function fecha(ev){
          if(!pop.contains(ev.target)&&ev.target!==btn){pop.remove();btn.setAttribute('aria-expanded','false');document.removeEventListener('click',fecha);}
        });
      },0);
    });
  });
})();
